from formation import Formation

MAX_COST = 50.0
MAX_SUBS = 8
    
FORMATION = Formation("4-4-2")
